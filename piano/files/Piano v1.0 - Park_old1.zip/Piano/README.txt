Piano v1.0.0
Application by John Park

This application was made in 2012 and improved in 2013. It was the final project for Foundations of Computer Science taught at TJHSST in 2011-2012.

You can play any note on the piano just like a full real 88 key piano. Feel free to try out each of the features!

RUN PIANO.EXE!

Controls

Keys:
Display key overlay	F1
Piano keys (white)	A, S, D, F, G, H, J, K, L, ;
Piano keys (black)	W, E, T, Y, U, O, P

Octave changes:
Shift left		Z
Shift right		C
Center octave		X

Damper pedal:	Hold shift or space bar while playing

Other:	Hold ` key to show beta feature panel (work in progress)

-
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT
WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. YOU MAY NOT DISTRIBUTE THIS SOFTWARE
WITHOUT PERMISSION FROM THE AUTHORS.

Copyright (c) 2013 John Park